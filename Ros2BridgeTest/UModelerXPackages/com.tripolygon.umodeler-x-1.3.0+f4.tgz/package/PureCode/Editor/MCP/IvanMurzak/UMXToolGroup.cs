using System.ComponentModel;
using System.Threading.Tasks;
using com.IvanMurzak.McpPlugin;
using UnityEngine;

namespace Tripolygon.UModelerX.Editor.MCP.IvanMurzak
{
    // IvanMurzak/Unity-MCP(com.ivanmurzak.unity.mcp) 어댑터.
    // 프로토콜 변환만 담당하고 실제 실행은 Core 의 *Operation 으로 위임.
    // 메서드 시그니처는 프레임워크가 JSON 스키마로 자동 변환하므로 그대로 유지한다.
    [McpPluginToolType]
    public class UMXToolGroup
    {
        [McpPluginTool("umx_parametric_shape", Title = "UModelerX / Parametric Shape")]
        [Description(UMXMcpUtility.SceneToolDescription)]
        public Task<object> Scene(
            [Description("Line-based UModelerX scene DSL script.")]
            string script)
        {
            return UMXMcpUtility.RunOnMainThread<object>(() => ToResponse(UMXSceneOperation.Execute(script)));
        }

        [McpPluginTool("umx_hotspot", Title = "UModelerX / Hotspot Layout")]
        [Description(UMXMcpUtility.HotspotToolDescription)]
        public Task<object> Hotspot(
            [Description("Line-based UModelerX hotspot layout DSL script.")]
            string script)
        {
            return UMXMcpUtility.RunOnMainThread<object>(() => ToResponse(UMXHotspotOperation.Execute(script)));
        }

        // IvanMurzak 프레임워크의 ReflectorNet 이 익명 타입을 거부할 수 있어 단순 컨테이너로 변환.
        private static object ToResponse(UMXMcpResult result)
        {
            return result.Success
                ? (object)new { success = true, message = result.Message, data = result.Data }
                : new { success = false, error = result.Message };
        }
    }
}
