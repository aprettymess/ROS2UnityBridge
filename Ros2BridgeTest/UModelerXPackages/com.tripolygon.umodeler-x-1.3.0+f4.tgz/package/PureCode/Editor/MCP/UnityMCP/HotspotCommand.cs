using System.Threading.Tasks;
using Unity.AI.MCP.Editor.Helpers;
using Unity.AI.MCP.Editor.ToolRegistry;

namespace Tripolygon.UModelerX.Editor.MCP
{
    public class HotspotParams
    {
        [McpDescription("Line-based UModelerX hotspot layout DSL script.", Required = true)]
        public string Script { get; set; }
    }

    // Unity.AI.MCP 어댑터. 프로토콜 변환만 담당하고 실제 실행은 UMXHotspotOperation 으로 위임.
    [McpTool(
        name: "umx_hotspot",
        description: UMXMcpUtility.HotspotToolDescription,
        title: "UModelerX: Hotspot Layout")]
    public class HotspotCommand : IUnityMcpTool<HotspotParams>
    {
        public Task<object> ExecuteAsync(HotspotParams parameters)
        {
            parameters ??= new HotspotParams();
            var result = UMXHotspotOperation.Execute(parameters.Script);
            object response = result.Success
                ? Response.Success(result.Message, result.Data)
                : Response.Error(result.Message);
            return Task.FromResult(response);
        }
    }
}
