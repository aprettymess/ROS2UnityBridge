using System.Threading.Tasks;
using MCPForUnity.Editor.Tools;
using Newtonsoft.Json.Linq;

namespace Tripolygon.UModelerX.Editor.MCP.Coplay
{
    // CoplayDev MCP 용 핫스팟 DSL 실행 커맨드.
    // 프로토콜 변환만 담당하고 실제 실행은 UMXHotspotOperation 으로 위임.
    [McpForUnityTool("umx_hotspot", Description = UMXMcpUtility.HotspotToolDescription)]
    public static class HotspotCommand
    {
        // 중첩 Parameters 클래스가 없으면 스키마 properties 가 비어 파라미터 매핑이 안 되고
        // batch_execute 경유가 강제된다 — ToolDiscoveryService 가 이 클래스에서 스키마를 추출한다.
        public class Parameters
        {
            [ToolParameter("Line-based UModelerX hotspot layout DSL script.", Required = true)]
            public string script { get; set; }
        }

        public static Task<object> HandleCommand(JObject @params)
        {
            @params ??= new JObject();
            var script = @params["script"]?.ToString();
            var result = UMXHotspotOperation.Execute(script);
            return Task.FromResult(CoplayMcpAdapter.ToResponse(result));
        }
    }
}
