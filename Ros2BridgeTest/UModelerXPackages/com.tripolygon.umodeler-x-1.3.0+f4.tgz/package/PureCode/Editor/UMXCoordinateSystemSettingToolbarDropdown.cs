﻿using UnityEditor;
using UnityEngine;
using System;

#if UNITY_2021_2_OR_NEWER
using UnityEditor.Toolbars;
#endif // UNITY_2021_2_OR_NEWER

namespace Tripolygon.UModelerX.Editor.Views.Toolbar
{
    public class UMXCoordinateSystemSettingToolbarDropdown
    {
#if UNITY_2021_2_OR_NEWER // For Unity 2021_2 ~ 6
        private static EditorToolbarDropdown dropdown;

        public UMXCoordinateSystemSettingToolbarDropdown(EditorToolbarDropdown toolbarDropdown)
        {
            dropdown = toolbarDropdown;
        }

        /// <summary>
        /// 누른 버튼을 대상으로 지정하고 메뉴를 연다.
        /// 대상이 static 이라 생성자에서만 잡아 두면 나중에 만들어진 인스턴스가 앞의 것을 덮어쓴다 —
        /// UMX Object 오버레이와 UMX Settings 폴백이 버튼을 하나씩 만들기 때문에, 숨겨진 쪽이 대상이 되면
        /// worldBound 가 0 이라 메뉴가 엉뚱한 자리에 뜨고 텍스트·아이콘도 그쪽만 갱신된다.
        /// </summary>
        public static void ShowDropdown(EditorToolbarDropdown target)
        {
            dropdown = target;
            ShowDropdown();
        }

        public static void ShowDropdown()
        {
            var rect = new Rect(dropdown.worldBound.position, new Vector2(0, 22));
            GenericMenu menu = new GenericMenu();
            foreach (UMXCoordinateSystem coordinateSystem in Enum.GetValues(typeof(UMXCoordinateSystem)))
            {
                menu.AddItem(new GUIContent(Enum.GetName(typeof(UMXCoordinateSystem), coordinateSystem)),
                    CoordinateSystemSetting.CoordinateSystem == coordinateSystem,
                    () => OnCoordinateSystemChanged(coordinateSystem));
            }
            menu.DropDown(rect);
        }
#else // For Unity 2020_1 ~ 2021_1
        private static ToolbarDropdownButton dropdown;

        public UMXCoordinateSystemSettingToolbarDropdown(ToolbarDropdownButton dropdownButton)
        {
            dropdown = dropdownButton;
            OnCoordinateSystemChanged(CoordinateSystemSetting.CoordinateSystem);
        }

        public static void ShowDropdown(object target)
        {
            if (target is Rect rectTarget)
            {
                var rect = rectTarget;
                GenericMenu menu = new GenericMenu();
                foreach (UMXCoordinateSystem coordinateSystem in Enum.GetValues(typeof(UMXCoordinateSystem)))
                {
                    menu.AddItem(new GUIContent(Enum.GetName(typeof(UMXCoordinateSystem), coordinateSystem)),
                        CoordinateSystemSetting.CoordinateSystem == coordinateSystem,
                        () => OnCoordinateSystemChanged(coordinateSystem));
                }
                menu.DropDown(rect);
            }
        }
#endif

        private static void OnCoordinateSystemChanged(UMXCoordinateSystem newCoordinateSystem)
        {
            if (dropdown.text != nameof(newCoordinateSystem))
            {
                CoordinateSystemSetting.CoordinateSystem = newCoordinateSystem;
                dropdown.text = Enum.GetName(typeof(UMXCoordinateSystem), newCoordinateSystem);
                dropdown.icon = TextureProvider.CreateContent(typeof(UMXCoordinateSystemSettingToolbarButton), dropdown.text);
                if (newCoordinateSystem == UMXCoordinateSystem.Local)
                {
                    Tools.pivotRotation = PivotRotation.Local;
                }
                else if (newCoordinateSystem == UMXCoordinateSystem.Global)
                {
                    Tools.pivotRotation = PivotRotation.Global;
                }
            }
        }
    }
}

