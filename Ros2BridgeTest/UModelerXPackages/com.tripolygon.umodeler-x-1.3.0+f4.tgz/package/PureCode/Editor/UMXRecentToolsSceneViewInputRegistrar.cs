// UMX_SCENEVIEW_IMGUI_INPUT 은 PureCode.Editor asmdef 의 versionDefines 에서 유니티 2023.1 미만일 때만 켜진다.
#if UMX_SCENEVIEW_IMGUI_INPUT
using Tripolygon.UModelerX.Editor.Views.RecentTools;
using UnityEditor;
using UnityEngine;

namespace Tripolygon.UModelerX.PureCode.Editor
{
    /// <summary>
    /// 2022.3 씬뷰에서 최근 툴 팝업의 트리거 입력(스페이스바)을 IMGUI 로 대신 받아 오버레이에 넘긴다.
    ///
    /// 씬뷰 호스트인 EditorWindow.rootVisualElement 는 pickingMode = Ignore 로 만들어지고,
    /// 씬을 그리는 IMGUIContainer 는 이 루트의 자식이 아니라 형제다. UITK 이벤트는 타깃과 그 조상으로만
    /// 전파되므로 씬 위에서 누른 포인터·키의 전파 경로에 루트가 들어가지 않는다.
    /// 즉 오버레이가 루트에 TrickleDown 으로 걸어둔 콜백이 씬뷰에서는 아예 호출되지 않는다.
    /// 2023.1 이후에는 타깃을 못 찾은 이벤트가 패널 루트로 폴백 디스패치되어 UITK 경로만으로 동작하므로
    /// 이 파일은 컴파일되지 않는다.
    /// </summary>
    [InitializeOnLoad]
    internal static class UMXRecentToolsSceneViewInputRegistrar
    {
        static UMXRecentToolsSceneViewInputRegistrar()
        {
            SceneView.duringSceneGui += OnSceneViewGUI;
        }

        private static void OnSceneViewGUI(SceneView sv)
        {
            if (sv == null || sv.rootVisualElement == null)
            {
                return;
            }

            // 오버레이가 붙어 있지 않으면(사용 안 함·씬 숨김) 입력도 볼 필요가 없다.
            var host = sv.rootVisualElement;
            if (UMXRecentToolsOverlay.IsInstalled(host) == false)
            {
                return;
            }

            var evt = Event.current;
            if (evt == null)
            {
                return;
            }

            // 씬뷰 카메라 조작이 먼저 소비하거나 커서가 창 밖으로 나가면 type 이 Used/Ignore 로 가려진다.
            // 커서 위치 추적이 끊기지 않도록 마우스는 rawType 으로 원래 종류를 본다.
            var mouseType = evt.rawType;
            switch (mouseType)
            {
                case EventType.MouseMove:
                case EventType.MouseDrag:
                case EventType.MouseDown:
                case EventType.MouseUp:
                    // 팝업 위치의 기준. 스페이스바 트리거는 키 이벤트에 좌표가 없어 이 값을 쓴다.
                    UMXRecentToolsOverlay.SetPointerPosition(host, evt.mousePosition);
                    break;
            }

            if (mouseType == EventType.MouseDown)
            {
                // 팝업 바깥을 누르면 닫는다. 팝업 위 클릭은 UITK 요소가 먼저 받으므로 여기까지 오지 않는다.
                UMXRecentToolsOverlay.ClosePopup(host);
            }

            // 키는 소비 여부를 존중해야 다른 단축키와 겹치지 않으므로 rawType 을 쓰지 않는다.
            if (evt.type != EventType.KeyDown)
            {
                return;
            }

            if (evt.keyCode == KeyCode.Escape)
            {
                if (UMXRecentToolsOverlay.ClosePopup(host))
                {
                    evt.Use();
                }
                return;
            }

            if (UMXRecentToolsSettings.Trigger != UMXRecentToolsTrigger.SpaceBar)
            {
                return;
            }
            if (evt.keyCode != KeyCode.Space || evt.modifiers != EventModifiers.None)
            {
                return;
            }

            // 같은 키로 토글한다. 열려 있으면 닫는다.
            if (UMXRecentToolsOverlay.TogglePopup(host))
            {
                evt.Use();
            }
        }
    }
}
#endif
