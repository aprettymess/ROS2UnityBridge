﻿using UnityEngine;
using UnityEditor;
using UnityEngine.UIElements;
using UnityEditor.Overlays;

namespace Tripolygon.UModelerX.Editor.Views.Toolbar
{
#if UNITY_6000_1_OR_NEWER // 2023 ~ 6
    [Overlay(typeof(SceneView), "UMX Settings", true, defaultLayout = Layout.HorizontalToolbar, defaultDockZone = DockZone.TopToolbar, defaultDockIndex = 0, priority = 200)]
#elif UNITY_2023_1_OR_NEWER // 2022 ~ 6
    // defaultDockIndex 로 상단 툴바 안에서의 기본 순서를 고정한다 (UMX Settings=0 / UMX Object=1 / UMX Mesh Ops=2).
    // 이미 오버레이 배치를 저장해 둔 사용자는 그 레이아웃이 우선하므로, 순서를 보려면 씬뷰 오버레이 메뉴에서 레이아웃을 초기화해야 한다.
    [Overlay(typeof(SceneView), "UMX Settings", true, defaultLayout = Layout.HorizontalToolbar, defaultDockZone = DockZone.TopToolbar, defaultDockIndex = 0)]
#else // 2021_2 ~ 2021_3
    [Overlay(typeof(SceneView), "UMX Settings", true)]
#endif

    [Icon("Assets/Unity-UModelerX/Editor/Resources/Tripolygon/UModelerX/Editor/Views/Toolbar/UMXSettingsToolbar.png")]
    public class UMXSettingsToolbar : ToolbarOverlay
    {
        // UMX Toolbar 추가 시 생성자 목록에도 같이 추가되어야함. 동일한 string.
        // Coordinate System / Element Snap 은 UMX Object 오버레이로 이동했지만, 그 오버레이를 꺼 두면
        // 닿을 경로가 없어지므로 개편 전 자리에 폴백 버튼을 함께 둔다.
        // 폴백은 UMX Object 오버레이가 떠 있는 동안 스스로 숨는다(UMXSettingsFallbackVisibility).
        // 양 끝(Display Settings / Global Lock)은 항상 보이므로 버튼 스트립 모서리 처리도 그대로 유지된다.
        public UMXSettingsToolbar() : base("SceneView/UMX Display Settings", "SceneView/UMX Snap Setting", UMXCoordinateSystemSettingFallbackButton.ElementId, UMXElementSnapSettingFallbackButton.ElementId, "SceneView/UMX Global Lock")
        {

        }

#if UNITY_2022_1_OR_NEWER
        public override void OnCreated()
        {
            // [Icon] 은 에셋 경로 고정이라 테마를 못 가린다. TextureProvider 가 @Light 폴더를 태운다.
            // 타입명 경로에 해당하는 리소스가 없으면 TextureProvider 가 Tripolygon/None(빨간 금지 아이콘)으로 폴백해 [Icon] 을 덮어쓴다.
            // 이 오버레이 전용 아이콘이므로 실존 경로를 직접 지정한다.
            this.collapsedIcon = TextureProvider.Load("Tripolygon/UModelerX/Editor/Views/Toolbar/UMXSettingsToolbar");
        }
#endif

#if !UNITY_2022_1_OR_NEWER
        public override void OnCreated()
        {
            UMXToolbarSetter.Init(this.containerWindow);
        }
#endif
    }
}
